import React, { useState, useEffect } from 'react';
import { 
    Home, 
    BookOpen, 
    ShoppingBasket, 
    Briefcase, 
    User, 
    Leaf, 
    Search, 
    Bell, 
    ChevronRight, 
    LogOut, 
    Settings, 
    Wallet, 
    History, 
    Users, 
    Shield, 
    Headphones,
    FileText,
    ArrowLeft,
    School,
    GraduationCap,
    MapPin,
    Calendar,
    DollarSign,
    Baby,
    Wifi,
    BriefcaseBusiness,
    CheckCircle,
    UserCheck,
    Globe,
    Clock,
    Library,
    Backpack,
    Scroll,
    Phone,
    Plus,
    Youtube,
    Smartphone,
    Type,
    ExternalLink,
    Send,
    CheckSquare,
    XCircle
} from 'lucide-react';
import { ViewState, Teacher, Student, TeachingMode, Job, JobSubmission } from './types';
import { TEACHERS_DATA, STUDENTS_DATA, PRODUCTS_DATA, DIGITAL_PRODUCTS_DATA, JOBS_DATA } from './constants';
import ProfileDetail from './components/ProfileDetail';

// --- HELPER COMPONENTS ---

// Advanced Avatar Generator based on User Type & Gender
const SmartAvatar = ({ gender, type, className = "w-full h-full" }: { gender: 'male' | 'female', type: 'madrasa' | 'school' | 'university' | undefined, className?: string }) => {
    if (gender === 'female') {
        return (
            <div className={`${className} bg-pink-50 text-pink-500 flex items-center justify-center relative overflow-hidden border-2 border-pink-100`}>
                <User size="60%" strokeWidth={1.5} />
                <div className="absolute bottom-0 w-full h-1/3 bg-pink-100/50"></div>
            </div>
        );
    }

    // Male Logic
    let bgClass = "bg-gray-100";
    let textClass = "text-gray-600";
    let Icon = User;
    let Badge = null;

    if (type === 'madrasa') {
        bgClass = "bg-emerald-50";
        textClass = "text-emerald-700";
        Icon = User; // Simulating "Islamic/Sunnah" look
        Badge = <Scroll size={14} className="text-emerald-600" />;
    } else if (type === 'school') {
        bgClass = "bg-blue-50";
        textClass = "text-blue-700";
        Icon = BriefcaseBusiness; // Simulating "Formal/Shirt" look
        Badge = <Backpack size={14} className="text-blue-600" />;
    } else if (type === 'university') {
        bgClass = "bg-purple-50";
        textClass = "text-purple-700";
        Icon = GraduationCap; // Explicit Grad look
        Badge = <Globe size={14} className="text-purple-600" />;
    }

    return (
        <div className={`${className} ${bgClass} ${textClass} flex items-center justify-center relative border-2 border-white shadow-sm`}>
            <Icon size="55%" strokeWidth={1.5} />
            {Badge && (
                <div className="absolute top-1 right-1 bg-white p-1 rounded-full shadow-sm">
                    {Badge}
                </div>
            )}
        </div>
    );
};

const ModeBadge = ({ mode }: { mode: TeachingMode }) => {
    let icon, text, color;
    if (mode === 'online') {
        icon = <Wifi size={10} />;
        text = "Online";
        color = "bg-blue-50 text-blue-600 border border-blue-100";
    } else if (mode === 'offline') {
        icon = <MapPin size={10} />;
        text = "Offline";
        color = "bg-orange-50 text-orange-600 border border-orange-100";
    } else {
        icon = <Globe size={10} />;
        text = "Hybrid";
        color = "bg-emerald-50 text-emerald-600 border border-emerald-100";
    }
    return (
        <span className={`flex items-center gap-1 text-[10px] uppercase font-bold px-2 py-1 rounded-md ${color}`}>
            {icon} {text}
        </span>
    );
};

// --- DATA LISTS FOR SELECTS ---
// Location list removed from UI usage as per request, but keeping array for potential future use or suggestions if needed.
const LOCATIONS = ['Mirpur', 'Uttara', 'Dhanmondi', 'Mohammadpur', 'Gulshan', 'Banani', 'Badda', 'Farmgate', 'Rampura', 'Malibagh', 'Old Dhaka', 'Savar', 'Keraniganj', 'Bashundhara', 'Khilkhet'];

// Categorized Subjects
const MADRASA_SUBJECTS = ['Quran Hifz', 'Nazera', 'Arabic Language', 'Hadith', 'Fiqh', 'Urdu', 'Masla Masail', 'Tajweed', 'Islamic Studies'];
const SCHOOL_SUBJECTS = ['Math', 'English', 'Bangla', 'General Science', 'Physics', 'Chemistry', 'Biology', 'ICT', 'Accounting', 'Arts'];
const UNIVERSITY_SUBJECTS = ['Physics', 'Chemistry', 'Math', 'English Spoken', 'IELTS', 'Programming', 'Medical Admission', 'Engineering Admission', 'University Admission', 'BBA/MBA Subjects'];

// Categorized Classes/Degrees
const MADRASA_CLASSES = [
    'Noorani (Basic)',
    'Nadia (Reading)',
    'Quran Hifz',
    'Class 1-5 (Ebtedayi)', 
    'Class 6-8 (JDC)', 
    'Class 9-10 (Dakhil/SSC)', 
    'Alim (HSC Equivalent)', 
    'Fazil (Honours Equivalent)', 
    'Kamil (Masters Equivalent)', 
    'Ifta (Fatwa/Specialty)'
];

const SCHOOL_CLASSES = [
    'Play Group', 
    'Nursery', 
    'KG', 
    'Class 1', 
    'Class 2', 
    'Class 3', 
    'Class 4', 
    'Class 5', 
    'Class 6', 
    'Class 7', 
    'Class 8', 
    'Class 9 (Science)', 
    'Class 9 (Commerce)', 
    'Class 9 (Arts)', 
    'Class 10 (SSC)', 
    'HSC 1st Year', 
    'HSC 2nd Year'
];

const UNIVERSITY_CLASSES = [
    'University Admission Prep', 
    'Diploma Engineering', 
    'B.Sc / Honours (1st-2nd Year)', 
    'B.Sc / Honours (3rd-4th Year)', 
    'BBA', 
    'M.Sc / Masters', 
    'MBA', 
    'MPhil', 
    'PhD'
];

const EXPERIENCE = ['Fresher', '1-2 Years', '3-5 Years', '5-10 Years', '10+ Years'];
const DAYS = ['2 Days/Week', '3 Days/Week', '4 Days/Week', '5 Days/Week', '6 Days/Week'];
const JOB_CATEGORIES = ['YouTube', 'Facebook', 'App Install', 'Review', 'Typing', 'Share', 'Other'];

// 1. Auth Component
const AuthScreen = ({ type, onSwitch, onLogin }: { type: 'login' | 'signup', onSwitch: (v: ViewState) => void, onLogin: () => void }) => {
    const [role, setRole] = useState<'teacher' | 'student'>('teacher');
    
    return (
        <div className="min-h-screen bg-white flex flex-col justify-center px-6 animate-slideUp z-50 relative">
            <div className="text-center mb-8">
                <Leaf className="mx-auto text-primary w-14 h-14 mb-2" />
                <h1 className="text-2xl font-bold text-primary-dark">
                    {type === 'login' ? 'Welcome Back' : 'Create Account'}
                </h1>
                <p className="text-text-light text-sm">
                    {type === 'login' ? 'Sign in to continue your journey' : 'Join the Halal Global Biz Community'}
                </p>
            </div>

            {type === 'signup' && (
                <div className="flex bg-gray-100 p-1 rounded-full mb-6">
                    <button 
                        onClick={() => setRole('teacher')}
                        className={`flex-1 py-3 rounded-full text-sm font-semibold transition-all ${role === 'teacher' ? 'bg-primary text-white shadow-md' : 'text-text-light'}`}
                    >
                        Teacher
                    </button>
                    <button 
                        onClick={() => setRole('student')}
                        className={`flex-1 py-3 rounded-full text-sm font-semibold transition-all ${role === 'student' ? 'bg-primary text-white shadow-md' : 'text-text-light'}`}
                    >
                        Student
                    </button>
                </div>
            )}

            <div className="space-y-4">
                {type === 'signup' && (
                    <div className="flex gap-3">
                         <input type="text" placeholder="First Name" className="w-full p-4 rounded-xl border bg-gray-50 focus:border-primary focus:bg-white outline-none transition" />
                         <input type="text" placeholder="Last Name" className="w-full p-4 rounded-xl border bg-gray-50 focus:border-primary focus:bg-white outline-none transition" />
                    </div>
                )}
                <input type="email" placeholder="Email Address" className="w-full p-4 rounded-xl border bg-gray-50 focus:border-primary focus:bg-white outline-none transition" />
                {type === 'signup' && <input type="tel" placeholder="Mobile Number" className="w-full p-4 rounded-xl border bg-gray-50 focus:border-primary focus:bg-white outline-none transition" />}
                <input type="password" placeholder="Password" className="w-full p-4 rounded-xl border bg-gray-50 focus:border-primary focus:bg-white outline-none transition" />
            </div>

            {type === 'login' && (
                <div className="text-right mt-3 mb-6">
                    <button className="text-text-light text-xs font-medium">Forgot Password?</button>
                </div>
            )}

            <button 
                onClick={onLogin}
                className="w-full bg-primary text-white py-4 rounded-xl font-bold text-lg shadow-lg shadow-primary/30 mt-6 active:scale-95 transition"
            >
                {type === 'login' ? 'Log In' : 'Sign Up'}
            </button>

            <div className="text-center mt-6 text-sm text-text-light">
                {type === 'login' ? "Don't have an account? " : "Already have an account? "}
                <button 
                    onClick={() => onSwitch(type === 'login' ? 'signup' : 'login')}
                    className="text-primary font-bold ml-1"
                >
                    {type === 'login' ? 'Sign Up' : 'Log In'}
                </button>
            </div>
        </div>
    );
};

// 2. Main App Container
export default function App() {
    const [view, setView] = useState<ViewState>('login');
    const [tuitionTab, setTuitionTab] = useState<'teachers' | 'students'>('teachers');
    const [selectedProfile, setSelectedProfile] = useState<{data: Teacher | Student, type: 'teacher' | 'student'} | null>(null);
    const [selectedJob, setSelectedJob] = useState<Job | null>(null);
    
    // Data State (Simulated Backend)
    const [teachersList, setTeachersList] = useState<Teacher[]>(TEACHERS_DATA);
    const [studentsList, setStudentsList] = useState<Student[]>(STUDENTS_DATA);
    
    // Jobs Data State
    const [jobsList, setJobsList] = useState<Job[]>(JOBS_DATA);
    
    // Job Creation Form
    const [jobFormData, setJobFormData] = useState({ 
        title: '', desc: '', reward: '', category: 'Other', link: '', count: '', proofContact: '' 
    });

    // BioData Form States
    const [bioType, setBioType] = useState<'teacher' | 'student'>('teacher');
    
    // Teacher Form Data
    const [tFormData, setTFormData] = useState<Partial<Teacher>>({
        name: '', gender: 'male', institutionType: 'madrasa', subject: '', location: '', targetArea: '', teachingMode: 'offline', fee: '', mobile: '', education: '', experience: '', about: ''
    });
    
    // Student Form Data
    const [sFormData, setSFormData] = useState<Partial<Student>>({
        name: '', gender: 'male', institutionType: 'school', need: '', classLevel: '', budget: '', location: '', teachingModePreference: 'offline', mobile: '', daysPerWeek: '', details: ''
    });

    // Reset subject/education when institution type changes to avoid mismatch
    useEffect(() => {
        setTFormData(prev => ({ ...prev, subject: '', education: '' }));
    }, [tFormData.institutionType]);

    useEffect(() => {
        setSFormData(prev => ({ ...prev, need: '', classLevel: '' }));
    }, [sFormData.institutionType]);

    // --- Helper to get subject list based on type ---
    const getSubjectList = (type: string | undefined) => {
        if (type === 'madrasa') return MADRASA_SUBJECTS;
        if (type === 'school') return SCHOOL_SUBJECTS;
        if (type === 'university') return UNIVERSITY_SUBJECTS;
        return SCHOOL_SUBJECTS; // Default
    };

    // --- Helper to get Class/Degree list based on type ---
    const getClassList = (type: string | undefined) => {
        if (type === 'madrasa') return MADRASA_CLASSES;
        if (type === 'school') return SCHOOL_CLASSES;
        if (type === 'university') return UNIVERSITY_CLASSES;
        return SCHOOL_CLASSES; // Default
    };

    // --- Actions ---
    const handleProfileClick = (data: Teacher | Student, type: 'teacher' | 'student') => {
        setSelectedProfile({ data, type });
    };

    const closeProfile = () => {
        setSelectedProfile(null);
    };

    const handlePostJob = () => {
        if (!jobFormData.title || !jobFormData.desc || !jobFormData.reward || !jobFormData.count || !jobFormData.proofContact) return;
        
        const newJob: Job = {
            id: Date.now(),
            title: jobFormData.title,
            desc: jobFormData.desc,
            reward: jobFormData.reward.includes('৳') ? jobFormData.reward : `৳ ${jobFormData.reward}`,
            category: jobFormData.category,
            link: jobFormData.link,
            totalWorkers: parseInt(jobFormData.count),
            completedWorkers: 0,
            proofContact: jobFormData.proofContact,
            postedBy: 12345, // Assuming current user ID
            submissions: []
        };

        setJobsList([newJob, ...jobsList]);
        setJobFormData({ title: '', desc: '', reward: '', category: 'Other', link: '', count: '', proofContact: '' });
        setView('job-history'); // Redirect to history to see posted job
    };

    const handleJobSubmit = (jobId: number) => {
        const updatedJobs = jobsList.map(job => {
            if (job.id === jobId) {
                return {
                    ...job,
                    submissions: [...job.submissions, {
                        id: Date.now(),
                        workerName: "You (User)",
                        status: 'pending' as const,
                        timestamp: new Date().toLocaleTimeString()
                    }]
                };
            }
            return job;
        });
        setJobsList(updatedJobs);
        setSelectedJob(null);
        setView('microjob');
        alert("Proof submitted successfully! Wait for approval.");
    };

    const handleApproveSubmission = (jobId: number, submissionId: number) => {
        const updatedJobs = jobsList.map(job => {
            if (job.id === jobId) {
                const newCompleted = job.completedWorkers + 1;
                // Update submission status
                const newSubmissions = job.submissions.map(sub => 
                    sub.id === submissionId ? { ...sub, status: 'approved' as const } : sub
                );
                
                return {
                    ...job,
                    completedWorkers: newCompleted,
                    submissions: newSubmissions
                };
            }
            return job;
        }).filter(job => job.completedWorkers < job.totalWorkers); // Auto delete if full

        setJobsList(updatedJobs);
    };

    const handleRejectSubmission = (jobId: number, submissionId: number) => {
        const updatedJobs = jobsList.map(job => {
            if (job.id === jobId) {
                const newSubmissions = job.submissions.map(sub => 
                    sub.id === submissionId ? { ...sub, status: 'rejected' as const } : sub
                );
                return { ...job, submissions: newSubmissions };
            }
            return job;
        });
        setJobsList(updatedJobs);
    };

    const handleSaveBioData = () => {
        if (bioType === 'teacher') {
            const newTeacher: Teacher = {
                id: Date.now(),
                name: tFormData.name || 'New Teacher',
                gender: tFormData.gender as 'male' | 'female' || 'male',
                institutionType: tFormData.institutionType as any || 'madrasa',
                subject: tFormData.subject || 'General',
                location: tFormData.location || 'Dhaka',
                targetArea: tFormData.targetArea || 'Any',
                teachingMode: tFormData.teachingMode || 'offline',
                fee: tFormData.fee ? `${tFormData.fee} BDT` : 'Negotiable',
                mobile: tFormData.mobile || '',
                education: tFormData.education || '',
                experience: tFormData.experience || 'Fresher',
                isVerified: false,
                about: tFormData.about || `Expert in ${tFormData.subject}`
            };
            setTeachersList([newTeacher, ...teachersList]);
        } else {
             const newStudent: Student = {
                id: Date.now(),
                name: sFormData.name || 'New Student',
                gender: sFormData.gender as 'male' | 'female' || 'male',
                institutionType: sFormData.institutionType as any || 'school',
                need: sFormData.need || 'Tuition Needed',
                classLevel: sFormData.classLevel || 'General',
                budget: sFormData.budget ? `${sFormData.budget} BDT` : 'Negotiable',
                location: sFormData.location || 'Dhaka',
                teachingModePreference: sFormData.teachingModePreference || 'offline',
                mobile: sFormData.mobile || '',
                daysPerWeek: sFormData.daysPerWeek || '3 Days',
                details: sFormData.details || ''
            };
            setStudentsList([newStudent, ...studentsList]);
        }
        setTuitionTab(bioType === 'teacher' ? 'teachers' : 'students');
        setView('tuition');
    };

    // --- Renderers ---

    const renderHeader = () => (
        <header className="sticky top-0 bg-white z-40 px-5 py-4 flex justify-between items-center shadow-sm">
            <div className="flex items-center gap-1 text-xl font-bold text-primary">
                <Leaf className="fill-current" />
                <span>Global<span className="text-gray-800">Biz</span></span>
            </div>
            
            {view === 'microjob' ? (
                <button 
                    onClick={() => setView('create-job')}
                    className="w-10 h-10 bg-emerald-50 text-primary rounded-full flex items-center justify-center hover:bg-primary hover:text-white transition shadow-sm border border-emerald-100"
                >
                    <Plus size={24} />
                </button>
            ) : (
                <div className="flex gap-4 text-gray-600">
                    <Search className="w-6 h-6 hover:text-primary transition cursor-pointer" />
                    <Bell className="w-6 h-6 hover:text-primary transition cursor-pointer" />
                </div>
            )}
        </header>
    );

    const renderBottomNav = () => (
        <nav className="fixed bottom-0 left-0 w-full bg-white border-t border-gray-100 flex justify-around py-3 pb-5 z-40 shadow-[0_-5px_20px_rgba(0,0,0,0.05)] rounded-t-3xl">
            {[
                { id: 'home', icon: Home, label: 'Home' },
                { id: 'tuition', icon: BookOpen, label: 'Tuition' },
                { id: 'shop', icon: ShoppingBasket, label: 'Shop' },
                { id: 'microjob', icon: Briefcase, label: 'Jobs' },
                { id: 'profile', icon: User, label: 'Profile' }
            ].map((item) => (
                <button 
                    key={item.id}
                    onClick={() => setView(item.id as ViewState)}
                    className={`flex flex-col items-center gap-1 transition-all ${view === item.id ? 'text-primary' : 'text-gray-400'}`}
                >
                    <item.icon className={`w-6 h-6 ${view === item.id ? 'fill-current' : ''}`} />
                    <span className="text-[10px] font-medium">{item.label}</span>
                    {view === item.id && <div className="w-1 h-1 bg-primary rounded-full mt-1"></div>}
                </button>
            ))}
        </nav>
    );

    const renderHome = () => (
        <div className="p-5 pb-24 animate-slideUp">
            <div className="bg-gradient-to-br from-emerald-600 to-emerald-800 text-white p-6 rounded-premium shadow-soft mb-6 relative overflow-hidden">
                <div className="absolute top-[-20px] right-[-20px] w-24 h-24 bg-white/10 rounded-full"></div>
                <h2 className="text-2xl font-bold mb-2 leading-tight">হালাল উপার্জনের<br/>বিশ্বস্ত মাধ্যম</h2>
                <p className="text-emerald-50 text-sm font-light opacity-90">শরিয়াহ সম্মত উপায়ে নিজের ক্যারিয়ার গড়ুন এবং হালাল পথে আয় নিশ্চিত করুন।</p>
            </div>

            <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-lg text-gray-800">Categories</h3>
            </div>

            <div className="grid grid-cols-3 gap-4 mb-8">
                {[
                    { id: 'tuition', icon: BookOpen, label: 'Tuition' },
                    { id: 'shop', icon: ShoppingBasket, label: 'Shop' },
                    { id: 'digital', icon: FileText, label: 'Digital' },
                    { id: 'microjob', icon: Briefcase, label: 'Jobs' },
                    { id: 'profile', icon: User, label: 'Profile' },
                    { id: 'help', icon: Headphones, label: 'Help' }
                ].map((cat) => (
                    <button 
                        key={cat.id}
                        onClick={() => cat.id !== 'help' && setView(cat.id as ViewState)}
                        className="bg-white p-4 rounded-premium shadow-soft flex flex-col items-center justify-center gap-2 border border-transparent hover:border-primary transition group"
                    >
                        <div className="bg-emerald-50 text-primary p-3 rounded-full group-hover:bg-primary group-hover:text-white transition">
                            <cat.icon size={24} />
                        </div>
                        <span className="text-xs font-semibold text-gray-700">{cat.label}</span>
                    </button>
                ))}
            </div>

            <div className="flex justify-between items-center mb-4">
                <h3 className="font-bold text-lg text-gray-800">Featured Teachers</h3>
                <span className="text-xs text-primary font-bold cursor-pointer">View All</span>
            </div>

            <div className="bg-white p-4 rounded-premium shadow-soft border border-gray-100 flex items-center gap-4">
                <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-emerald-100">
                    <SmartAvatar gender="male" type="madrasa" />
                </div>
                <div>
                    <h4 className="font-bold text-gray-800">Hafizur Rahman</h4>
                    <p className="text-xs text-gray-500">Quran & Arabic • Dhaka</p>
                    <span className="inline-block bg-emerald-100 text-emerald-800 text-[10px] px-3 py-1 rounded-full font-bold mt-1">Verified</span>
                </div>
            </div>
        </div>
    );

    const renderTuition = () => (
        <div className="p-5 pb-24 animate-slideUp">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Tuition Portal</h2>
            
            <div className="flex bg-gray-200 p-1 rounded-full mb-6">
                <button 
                    onClick={() => setTuitionTab('teachers')}
                    className={`flex-1 py-2 text-sm font-semibold rounded-full transition ${tuitionTab === 'teachers' ? 'bg-primary text-white shadow-md' : 'text-gray-500'}`}
                >
                    Teachers
                </button>
                <button 
                    onClick={() => setTuitionTab('students')}
                    className={`flex-1 py-2 text-sm font-semibold rounded-full transition ${tuitionTab === 'students' ? 'bg-primary text-white shadow-md' : 'text-gray-500'}`}
                >
                    Students
                </button>
            </div>

            <div className="space-y-4">
                {tuitionTab === 'teachers' ? (
                    teachersList.map((t) => (
                        <div 
                            key={t.id} 
                            onClick={() => handleProfileClick(t, 'teacher')}
                            className="bg-white rounded-2xl p-5 shadow-sm hover:shadow-lg border border-gray-100 transition-all duration-300 cursor-pointer relative group"
                        >
                            {/* Top Section: Avatar & Badges */}
                            <div className="flex justify-between items-start mb-3">
                                <div className="w-16 h-16 rounded-2xl overflow-hidden border border-gray-100 bg-gray-50">
                                    <SmartAvatar gender={t.gender} type={t.institutionType} />
                                </div>
                                <div className="flex flex-col items-end gap-2">
                                     <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider border ${t.institutionType === 'madrasa' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : t.institutionType === 'school' ? 'bg-blue-50 text-blue-600 border-blue-100' : 'bg-purple-50 text-purple-600 border-purple-100'}`}>
                                        {t.institutionType}
                                     </span>
                                     <ModeBadge mode={t.teachingMode} />
                                </div>
                            </div>

                            {/* Info Section */}
                            <div className="mb-4">
                                <h4 className="text-lg font-bold text-gray-800 leading-tight mb-1">{t.name}</h4>
                                <p className="text-xs font-medium text-gray-500">{t.education}</p>
                            </div>

                            {/* Details Tag */}
                            <div className="bg-gray-50 rounded-xl p-3 border border-gray-100 mb-3 group-hover:bg-gray-100 transition-colors">
                                <p className="text-[10px] uppercase font-bold text-gray-400 mb-1">Subject</p>
                                <p className="text-sm font-semibold text-gray-700 line-clamp-1">{t.subject}</p>
                            </div>

                            {/* Footer */}
                            <div className="flex items-center justify-between pt-2">
                                <div className="flex items-center gap-1 text-xs text-gray-500">
                                    <MapPin size={14} className="text-gray-400"/> 
                                    <span className="truncate max-w-[120px]">{t.location}</span>
                                </div>
                                <span className="font-bold text-sm text-primary bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                                    {t.fee}
                                </span>
                            </div>
                        </div>
                    ))
                ) : (
                    studentsList.map((s) => (
                         <div 
                            key={s.id} 
                            onClick={() => handleProfileClick(s, 'student')}
                            className="bg-white rounded-2xl p-5 shadow-sm hover:shadow-lg border border-gray-100 transition-all duration-300 cursor-pointer relative group"
                        >
                             {/* Top Section: Avatar & Badges */}
                             <div className="flex justify-between items-start mb-3">
                                <div className="w-16 h-16 rounded-2xl overflow-hidden border border-gray-100 bg-gray-50">
                                    <SmartAvatar gender={s.gender} type={s.institutionType} />
                                </div>
                                <div className="flex flex-col items-end gap-2">
                                     <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider border ${s.institutionType === 'madrasa' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : s.institutionType === 'school' ? 'bg-blue-50 text-blue-600 border-blue-100' : 'bg-purple-50 text-purple-600 border-purple-100'}`}>
                                        {s.institutionType?.toUpperCase() || 'STUDENT'}
                                     </span>
                                     <ModeBadge mode={s.teachingModePreference} />
                                </div>
                             </div>

                             {/* Info Section */}
                             <div className="mb-4">
                                 <h4 className="text-lg font-bold text-gray-800 leading-tight mb-1">{s.name}</h4>
                                 <span className="text-[10px] bg-gray-100 text-gray-600 px-2 py-1 rounded font-bold uppercase">{s.classLevel}</span>
                             </div>

                             {/* Details Tag */}
                             <div className="bg-gray-50 rounded-xl p-3 border border-gray-100 mb-3 group-hover:bg-gray-100 transition-colors">
                                 <p className="text-[10px] uppercase font-bold text-gray-400 mb-1">Requirement</p>
                                 <p className="text-sm font-semibold text-gray-700 line-clamp-1">{s.need}</p>
                             </div>

                             {/* Footer */}
                             <div className="flex items-center justify-between pt-2">
                                <div className="flex items-center gap-1 text-xs text-gray-500">
                                    <MapPin size={14} className="text-gray-400"/> 
                                    <span className="truncate max-w-[120px]">{s.location}</span>
                                </div>
                                <span className="font-bold text-sm text-primary bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                                    {s.budget}
                                </span>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );

    const renderShop = (isDigital: boolean) => (
        <div className="p-5 pb-24 animate-slideUp">
            <h2 className="text-xl font-bold text-gray-800 mb-4">{isDigital ? 'Digital Assets' : 'Halal Shop'}</h2>
            <div className="grid grid-cols-2 gap-4">
                {(isDigital ? DIGITAL_PRODUCTS_DATA : PRODUCTS_DATA).map((p) => (
                    <div key={p.id} className="bg-white p-3 rounded-premium shadow-soft border border-gray-100">
                        <div className="h-32 bg-gray-50 rounded-xl mb-3 flex items-center justify-center text-gray-300">
                            <ShoppingBasket size={40} />
                        </div>
                        <h4 className="font-semibold text-sm text-gray-800 truncate">{p.name}</h4>
                        <p className="text-primary font-bold">{p.price}</p>
                        <button className={`w-full mt-2 py-2 rounded-lg text-xs font-semibold ${isDigital ? 'bg-primary text-white' : 'bg-gray-800 text-white'}`}>
                            {isDigital ? 'Download' : 'Add to Cart'}
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );

    const renderJobs = () => (
        <div className="p-5 pb-24 animate-slideUp">
             <h2 className="text-xl font-bold text-gray-800 mb-4">Micro Tasks</h2>
             <div className="grid grid-cols-2 gap-4">
                {jobsList.map((job) => (
                    <div key={job.id} className="bg-white p-4 rounded-premium shadow-soft border border-gray-100 flex flex-col items-center justify-between text-center gap-2 group hover:border-emerald-200 transition">
                        <div className="w-12 h-12 rounded-full bg-emerald-50 flex items-center justify-center text-primary group-hover:scale-110 transition">
                            {job.category === 'YouTube' ? <Youtube size={24} /> : 
                             job.category === 'App' ? <Smartphone size={24} /> :
                             job.category === 'Typing' ? <Type size={24} /> : <Briefcase size={24} />}
                        </div>
                        <div>
                            <h4 className="font-bold text-gray-800 text-sm line-clamp-1">{job.title}</h4>
                            <p className="text-[10px] text-gray-500 font-medium bg-gray-50 px-2 py-0.5 rounded-md inline-block mt-1">{job.completedWorkers}/{job.totalWorkers} Done</p>
                        </div>
                        <div className="w-full">
                            <p className="text-primary font-bold text-sm mb-2">{job.reward}</p>
                            <button 
                                onClick={() => {
                                    setSelectedJob(job);
                                    setView('job-detail');
                                }}
                                className="w-full bg-gray-800 text-white text-xs font-bold py-2 rounded-lg hover:bg-black transition"
                            >
                                View Job
                            </button>
                        </div>
                    </div>
                ))}
             </div>
        </div>
    );

    const renderJobDetail = () => {
        if (!selectedJob) return null;
        return (
            <div className="absolute top-0 left-0 w-full min-h-screen bg-white z-50 animate-slideUp overflow-y-auto">
                 {/* Header */}
                 <div className="h-40 bg-emerald-600 relative rounded-b-3xl">
                     <button onClick={() => setView('microjob')} className="absolute top-4 left-4 bg-white/20 backdrop-blur-md p-2 rounded-full text-white hover:bg-white/30 transition">
                         <ArrowLeft size={24} />
                     </button>
                     <div className="absolute -bottom-10 left-1/2 transform -translate-x-1/2">
                         <div className="w-24 h-24 bg-white rounded-2xl shadow-lg flex items-center justify-center text-primary border-4 border-white">
                             {selectedJob.category === 'YouTube' ? <Youtube size={40} /> : 
                              selectedJob.category === 'App' ? <Smartphone size={40} /> :
                              selectedJob.category === 'Typing' ? <Type size={40} /> : <Briefcase size={40} />}
                         </div>
                     </div>
                 </div>

                 <div className="pt-14 px-6 pb-10 text-center">
                     <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{selectedJob.category} Task</span>
                     <h2 className="text-2xl font-bold text-gray-800 mt-1 mb-2">{selectedJob.title}</h2>
                     <div className="inline-block bg-emerald-50 text-emerald-700 font-bold px-4 py-1 rounded-full border border-emerald-100 mb-6">
                         Reward: {selectedJob.reward}
                     </div>

                     <div className="bg-gray-50 rounded-xl p-5 border border-gray-100 text-left mb-6">
                         <h4 className="font-bold text-gray-700 mb-2 flex items-center gap-2"><FileText size={16}/> Instructions</h4>
                         <p className="text-sm text-gray-600 leading-relaxed">{selectedJob.desc}</p>
                         {selectedJob.link && (
                             <a 
                                href={selectedJob.link} 
                                target="_blank" 
                                rel="noreferrer" 
                                className="mt-4 flex items-center justify-center gap-2 w-full bg-blue-50 text-blue-600 py-3 rounded-lg font-bold text-sm hover:bg-blue-100 transition border border-blue-100"
                             >
                                 <ExternalLink size={16} /> Go to Task Link
                             </a>
                         )}
                     </div>

                     <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6">
                         <h4 className="font-bold text-gray-800 mb-4">Submit Proof</h4>
                         <p className="text-xs text-gray-500 mb-4">
                             1. Complete the task.<br/>
                             2. Send screenshot to Admin via WhatsApp/Telegram.<br/>
                             3. Come back and click "Confirm Submission".
                         </p>
                         <div className="space-y-3">
                             <a 
                                href={selectedJob.proofContact}
                                target="_blank"
                                rel="noreferrer"
                                className="flex items-center justify-center gap-2 w-full bg-green-500 text-white py-3 rounded-xl font-bold shadow-md hover:bg-green-600 transition"
                             >
                                 <Send size={18} /> Send Proof (WA/TG)
                             </a>
                             <button 
                                onClick={() => handleJobSubmit(selectedJob.id)}
                                className="flex items-center justify-center gap-2 w-full bg-gray-800 text-white py-3 rounded-xl font-bold shadow-md hover:bg-black transition"
                             >
                                 <CheckCircle size={18} /> Confirm Submission
                             </button>
                         </div>
                     </div>
                 </div>
            </div>
        )
    };

    const renderCreateJob = () => (
        <div className="absolute top-0 left-0 w-full min-h-screen bg-white z-50 p-5 pb-10 animate-slideUp overflow-y-auto">
             <div className="flex items-center gap-4 border-b border-gray-100 pb-4 mb-6 sticky top-0 bg-white z-10 pt-2 shadow-sm">
                 <button onClick={() => setView('microjob')} className="w-10 h-10 bg-gray-50 rounded-full flex items-center justify-center hover:bg-gray-100 transition">
                     <ArrowLeft className="text-gray-700" />
                 </button>
                 <h2 className="text-xl font-bold text-gray-800">Post New Job</h2>
             </div>

             <div className="space-y-6">
                <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden p-4 space-y-4">
                    <div>
                        <label className="block text-xs font-bold text-gray-600 mb-2">Category</label>
                        <select 
                            value={jobFormData.category}
                            onChange={(e) => setJobFormData({...jobFormData, category: e.target.value})}
                            className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary appearance-none"
                        >
                            {JOB_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-600 mb-2">Job Title</label>
                        <input 
                            value={jobFormData.title}
                            onChange={(e) => setJobFormData({...jobFormData, title: e.target.value})}
                            className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" placeholder="e.g. Subscribe Channel" 
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-600 mb-2">Task Description</label>
                        <textarea 
                            value={jobFormData.desc}
                            onChange={(e) => setJobFormData({...jobFormData, desc: e.target.value})}
                            className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary h-24 focus:ring-1 focus:ring-primary/20 transition" placeholder="Detailed instructions..." 
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-600 mb-2">Work Link (Where to go)</label>
                        <input 
                            value={jobFormData.link}
                            onChange={(e) => setJobFormData({...jobFormData, link: e.target.value})}
                            className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" placeholder="https://..." 
                        />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                        <div>
                            <label className="block text-xs font-bold text-gray-600 mb-2">Worker Quantity</label>
                            <input 
                                value={jobFormData.count}
                                onChange={(e) => setJobFormData({...jobFormData, count: e.target.value})}
                                type="number"
                                className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" placeholder="e.g. 50" 
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-600 mb-2">Reward (BDT)</label>
                            <div className="relative">
                                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-xs">৳</span>
                                <input 
                                    value={jobFormData.reward}
                                    onChange={(e) => setJobFormData({...jobFormData, reward: e.target.value})}
                                    type="number"
                                    className="w-full pl-6 p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" placeholder="10.00" 
                                />
                            </div>
                        </div>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-600 mb-2">Proof Contact (WA/TG Link)</label>
                        <input 
                            value={jobFormData.proofContact}
                            onChange={(e) => setJobFormData({...jobFormData, proofContact: e.target.value})}
                            className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" placeholder="https://wa.me/..." 
                        />
                    </div>
                </div>

                <button 
                    onClick={handlePostJob}
                    className="w-full bg-primary text-white py-4 rounded-xl font-bold shadow-lg shadow-primary/30 mt-6 active:scale-95 transition"
                >
                    Publish Job
                </button>
             </div>
        </div>
    );

    const renderJobHistory = () => {
        // Filter jobs posted by "current user" (ID 12345)
        const myJobs = jobsList.filter(job => job.postedBy === 12345);

        return (
            <div className="absolute top-0 left-0 w-full min-h-screen bg-white z-50 p-5 pb-10 animate-slideUp overflow-y-auto">
                 <div className="flex items-center gap-4 border-b border-gray-100 pb-4 mb-6 sticky top-0 bg-white z-10 pt-2 shadow-sm">
                     <button onClick={() => setView('profile')} className="w-10 h-10 bg-gray-50 rounded-full flex items-center justify-center hover:bg-gray-100 transition">
                         <ArrowLeft className="text-gray-700" />
                     </button>
                     <h2 className="text-xl font-bold text-gray-800">Job History</h2>
                 </div>

                 {myJobs.length === 0 ? (
                     <div className="text-center text-gray-400 mt-20">
                         <Briefcase size={48} className="mx-auto mb-2 opacity-50"/>
                         <p>No jobs posted yet.</p>
                     </div>
                 ) : (
                     <div className="space-y-6">
                        {myJobs.map(job => (
                            <div key={job.id} className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
                                <div className="flex justify-between items-start mb-3 border-b border-gray-50 pb-2">
                                    <div>
                                        <h4 className="font-bold text-gray-800">{job.title}</h4>
                                        <p className="text-xs text-gray-500">{job.category} • {job.completedWorkers}/{job.totalWorkers} Filled</p>
                                    </div>
                                    <span className="text-primary font-bold text-sm bg-emerald-50 px-2 py-1 rounded">{job.reward}</span>
                                </div>
                                
                                <h5 className="text-xs font-bold text-gray-400 uppercase mb-2">Submissions ({job.submissions.length})</h5>
                                <div className="space-y-2">
                                    {job.submissions.length === 0 ? (
                                        <p className="text-xs text-gray-400 italic">No submissions yet.</p>
                                    ) : (
                                        job.submissions.map(sub => (
                                            <div key={sub.id} className="flex justify-between items-center bg-gray-50 p-2 rounded-lg">
                                                <div>
                                                    <p className="text-xs font-bold text-gray-700">{sub.workerName}</p>
                                                    <p className="text-[10px] text-gray-500">{sub.timestamp}</p>
                                                </div>
                                                {sub.status === 'pending' ? (
                                                    <div className="flex gap-2">
                                                        <button 
                                                            onClick={() => handleApproveSubmission(job.id, sub.id)}
                                                            className="p-1.5 bg-green-100 text-green-600 rounded hover:bg-green-200" title="Approve"
                                                        >
                                                            <CheckSquare size={16}/>
                                                        </button>
                                                        <button 
                                                            onClick={() => handleRejectSubmission(job.id, sub.id)}
                                                            className="p-1.5 bg-red-100 text-red-600 rounded hover:bg-red-200" title="Reject"
                                                        >
                                                            <XCircle size={16}/>
                                                        </button>
                                                    </div>
                                                ) : (
                                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded capitalize ${sub.status === 'approved' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                                                        {sub.status}
                                                    </span>
                                                )}
                                            </div>
                                        ))
                                    )}
                                </div>
                            </div>
                        ))}
                     </div>
                 )}
            </div>
        );
    }

    const renderProfile = () => (
        <div className="p-5 pb-24 animate-slideUp">
             <div className="bg-gradient-to-br from-emerald-600 to-emerald-800 p-5 rounded-premium text-white shadow-hover mb-6 relative overflow-hidden">
                 <div className="absolute top-[-20px] right-[-20px] w-24 h-24 bg-white/10 rounded-full"></div>
                 <div className="flex items-center justify-between relative z-10">
                     <div className="flex items-center gap-3">
                         <div className="w-14 h-14 rounded-full bg-white text-primary flex items-center justify-center text-xl font-bold border-2 border-white/50">
                             <User />
                         </div>
                         <div>
                             <h3 className="font-bold text-lg">Md. Rahim</h3>
                             <p className="text-xs opacity-80">@rahimbiz24</p>
                         </div>
                     </div>
                     <div className="text-right">
                         <p className="text-[10px] uppercase tracking-wider opacity-80">Balance</p>
                         <p className="text-xl font-bold bg-white/20 px-2 py-1 rounded inline-block mt-1">৳ 12,500</p>
                     </div>
                 </div>
             </div>

             <h3 className="text-sm font-bold text-gray-800 mb-3">Bio-Data Management</h3>
             <div className="bg-white rounded-premium shadow-soft border border-gray-100 mb-6 overflow-hidden">
                 <div 
                    onClick={() => setView('biodata')}
                    className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-50 transition"
                >
                     <div className="flex items-center gap-3">
                         <div className="w-9 h-9 rounded-xl bg-emerald-50 text-primary flex items-center justify-center"><FileText size={18} /></div>
                         <span className="text-sm font-semibold text-gray-700">My Bio-Data (CV)</span>
                     </div>
                     <ChevronRight size={16} className="text-gray-300" />
                 </div>
             </div>

             <h3 className="text-sm font-bold text-gray-800 mb-3">Job Management</h3>
             <div className="bg-white rounded-premium shadow-soft border border-gray-100 mb-6 overflow-hidden">
                 <div 
                    onClick={() => setView('job-history')}
                    className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-50 transition"
                >
                     <div className="flex items-center gap-3">
                         <div className="w-9 h-9 rounded-xl bg-orange-50 text-orange-500 flex items-center justify-center"><Briefcase size={18} /></div>
                         <span className="text-sm font-semibold text-gray-700">My Posted Jobs (History)</span>
                     </div>
                     <ChevronRight size={16} className="text-gray-300" />
                 </div>
             </div>

             <h3 className="text-sm font-bold text-gray-800 mb-3">Account & Settings</h3>
             <div className="bg-white rounded-premium shadow-soft border border-gray-100 mb-6 overflow-hidden divide-y divide-gray-50">
                 {[
                     { icon: User, label: "Edit Profile", color: "bg-blue-50 text-blue-500" },
                     { icon: Wallet, label: "Withdraw Funds", color: "bg-emerald-50 text-emerald-500" },
                     { icon: History, label: "Task History", color: "bg-purple-50 text-purple-500" },
                 ].map((item, i) => (
                    <div key={i} className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-50 transition">
                        <div className="flex items-center gap-3">
                            <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${item.color}`}><item.icon size={18} /></div>
                            <span className="text-sm font-semibold text-gray-700">{item.label}</span>
                        </div>
                        <ChevronRight size={16} className="text-gray-300" />
                    </div>
                 ))}
             </div>

             <h3 className="text-sm font-bold text-gray-800 mb-3">Support</h3>
             <div className="bg-white rounded-premium shadow-soft border border-gray-100 mb-6 overflow-hidden divide-y divide-gray-50">
                 {[
                     { icon: Users, label: "Refer & Earn", color: "bg-orange-50 text-orange-500" },
                     { icon: Shield, label: "Security", color: "bg-blue-50 text-blue-500" },
                     { icon: Headphones, label: "Help Center", color: "bg-purple-50 text-purple-500" },
                 ].map((item, i) => (
                    <div key={i} className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-50 transition">
                        <div className="flex items-center gap-3">
                            <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${item.color}`}><item.icon size={18} /></div>
                            <span className="text-sm font-semibold text-gray-700">{item.label}</span>
                        </div>
                        <ChevronRight size={16} className="text-gray-300" />
                    </div>
                 ))}
             </div>

             <button 
                onClick={() => setView('login')}
                className="w-full bg-red-50 text-red-500 py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2"
            >
                 <LogOut size={18} /> Log Out
             </button>
        </div>
    );

    const renderBioData = () => (
        <div className="absolute top-0 left-0 w-full min-h-screen bg-white z-50 p-5 pb-10 animate-slideUp overflow-y-auto">
             <div className="flex items-center gap-4 border-b border-gray-100 pb-4 mb-6 sticky top-0 bg-white z-10 pt-2 shadow-sm">
                 <button onClick={() => setView('profile')} className="w-10 h-10 bg-gray-50 rounded-full flex items-center justify-center hover:bg-gray-100 transition">
                     <ArrowLeft className="text-gray-700" />
                 </button>
                 <h2 className="text-xl font-bold text-gray-800">Bio-Data Builder</h2>
             </div>

             <div className="flex bg-gray-100 p-1 rounded-xl mb-6 border border-gray-200">
                <button 
                    onClick={() => setBioType('teacher')} 
                    className={`flex-1 py-3 text-sm font-bold rounded-lg transition-all ${bioType === 'teacher' ? 'bg-white text-primary shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                    Teacher CV
                </button>
                <button 
                    onClick={() => setBioType('student')}
                    className={`flex-1 py-3 text-sm font-bold rounded-lg transition-all ${bioType === 'student' ? 'bg-white text-primary shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                    Student Request
                </button>
             </div>

             <div className="bg-gradient-to-b from-gray-50 to-white p-6 rounded-premium border border-dashed border-gray-300 flex flex-col items-center justify-center mb-6">
                 <div className="w-24 h-24 rounded-full flex items-center justify-center shadow-lg border-4 border-white mb-3 overflow-hidden">
                     {bioType === 'teacher' 
                        ? <SmartAvatar gender={tFormData.gender as any} type={tFormData.institutionType as any} />
                        : <SmartAvatar gender={sFormData.gender as any} type={sFormData.institutionType as any} />
                     }
                 </div>
                 <span className="text-xs font-semibold text-gray-500">Preview Avatar</span>
             </div>

             {bioType === 'teacher' ? (
                // --- TEACHER FORM ---
                <div className="space-y-6 animate-slideUp">
                    {/* SECTION A */}
                    <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                         <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex items-center gap-2">
                             <User size={16} className="text-primary"/>
                             <h4 className="text-sm font-bold text-gray-700">Personal Information</h4>
                         </div>
                         <div className="p-4 space-y-4">
                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">Full Name</label>
                                 <input 
                                    value={tFormData.name}
                                    onChange={(e) => setTFormData({...tFormData, name: e.target.value})}
                                    className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" placeholder="e.g. Abdullah" 
                                 />
                             </div>
                             
                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">Gender</label>
                                 <div className="flex gap-3">
                                    {['male', 'female'].map(g => (
                                        <label key={g} className={`flex-1 p-3 border rounded-lg flex items-center justify-center gap-2 cursor-pointer transition ${tFormData.gender === g ? (g === 'male' ? 'bg-emerald-50 border-emerald-500 text-emerald-700' : 'bg-pink-50 border-pink-500 text-pink-700') : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50'}`}>
                                            <input type="radio" name="t_gender" checked={tFormData.gender === g} onChange={() => setTFormData({...tFormData, gender: g as any})} className="hidden"/> 
                                            {g === 'male' ? <User size={16} /> : <User size={16} />}
                                            <span className="text-sm font-medium capitalize">{g}</span>
                                        </label>
                                    ))}
                                 </div>
                             </div>

                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">Mobile Number</label>
                                 <div className="relative">
                                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                                    <input 
                                        value={tFormData.mobile}
                                        onChange={(e) => setTFormData({...tFormData, mobile: e.target.value})}
                                        type="tel" className="w-full pl-10 p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" placeholder="01XXXXXXXXX" 
                                    />
                                 </div>
                             </div>
                         </div>
                    </div>

                    {/* SECTION B */}
                    <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                         <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex items-center gap-2">
                             <GraduationCap size={16} className="text-primary"/>
                             <h4 className="text-sm font-bold text-gray-700">Education & Experience</h4>
                         </div>
                         <div className="p-4 space-y-4">
                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">Institution Type</label>
                                 <div className="grid grid-cols-3 gap-3">
                                    {[
                                        { id: 'madrasa', icon: Scroll, label: 'Madrasa' },
                                        { id: 'school', icon: Backpack, label: 'School' },
                                        { id: 'university', icon: GraduationCap, label: 'Varsity' }
                                    ].map((type) => (
                                        <div 
                                            key={type.id}
                                            onClick={() => setTFormData({...tFormData, institutionType: type.id as any})}
                                            className={`p-3 border rounded-xl flex flex-col items-center justify-center gap-2 cursor-pointer transition-all ${tFormData.institutionType === type.id ? 'bg-primary text-white border-primary shadow-md transform scale-105' : 'bg-white text-gray-500 border-gray-200 hover:bg-gray-50'}`}
                                        >
                                            <type.icon size={20} />
                                            <span className="text-[10px] font-bold">{type.label}</span>
                                        </div>
                                    ))}
                                 </div>
                             </div>

                             <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className="block text-xs font-bold text-gray-600 mb-2">Degree/Class</label>
                                    <select 
                                        value={tFormData.education}
                                        onChange={(e) => setTFormData({...tFormData, education: e.target.value})}
                                        className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary appearance-none"
                                    >
                                        <option value="" disabled>Select</option>
                                        {getClassList(tFormData.institutionType).map(d => <option key={d} value={d}>{d}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-600 mb-2">Experience</label>
                                    <select 
                                        value={tFormData.experience}
                                        onChange={(e) => setTFormData({...tFormData, experience: e.target.value})}
                                        className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary appearance-none"
                                    >
                                        <option value="" disabled>Select</option>
                                        {EXPERIENCE.map(e => <option key={e} value={e}>{e}</option>)}
                                    </select>
                                </div>
                             </div>
                         </div>
                    </div>

                    {/* SECTION C */}
                    <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                         <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex items-center gap-2">
                             <BookOpen size={16} className="text-primary"/>
                             <h4 className="text-sm font-bold text-gray-700">Tuition Preferences</h4>
                         </div>
                         <div className="p-4 space-y-4">
                             <div>
                                <label className="block text-xs font-bold text-gray-600 mb-2">Teaching Mode</label>
                                <div className="flex gap-2">
                                    {['offline', 'online', 'both'].map((m) => (
                                        <button 
                                            key={m}
                                            onClick={() => setTFormData({...tFormData, teachingMode: m as any})}
                                            className={`flex-1 py-2 rounded-lg text-xs font-bold border transition-all ${tFormData.teachingMode === m ? 'bg-gray-800 text-white border-gray-800 shadow' : 'bg-white text-gray-500 border-gray-200 hover:bg-gray-50'}`}
                                        >
                                            {m.toUpperCase()}
                                        </button>
                                    ))}
                                </div>
                             </div>

                             <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className="block text-xs font-bold text-gray-600 mb-2">Subject</label>
                                    <select 
                                        value={tFormData.subject}
                                        onChange={(e) => setTFormData({...tFormData, subject: e.target.value})}
                                        className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary appearance-none"
                                    >
                                        <option value="" disabled>Select Subject</option>
                                        {getSubjectList(tFormData.institutionType).map(s => <option key={s} value={s}>{s}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-600 mb-2">Fee (BDT)</label>
                                    <div className="relative">
                                        <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-xs">৳</span>
                                        <input 
                                            value={tFormData.fee?.replace(' BDT', '')}
                                            onChange={(e) => setTFormData({...tFormData, fee: e.target.value})}
                                            type="number"
                                            className="w-full pl-6 p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" 
                                            placeholder="e.g. 5000" 
                                        />
                                    </div>
                                </div>
                             </div>
                             
                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">Present Location</label>
                                 <div className="relative">
                                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                                    <input 
                                        value={tFormData.location}
                                        onChange={(e) => setTFormData({...tFormData, location: e.target.value})}
                                        className="w-full pl-10 p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" 
                                        placeholder="e.g. Mirpur 10, Dhaka"
                                    />
                                 </div>
                             </div>
                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">Target Areas (Teaching Area)</label>
                                 <div className="relative">
                                     <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                                     <input 
                                        value={tFormData.targetArea}
                                        onChange={(e) => setTFormData({...tFormData, targetArea: e.target.value})}
                                        className="w-full pl-10 p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition"
                                        placeholder="e.g. Uttara, Banani, Gulshan"
                                     />
                                 </div>
                             </div>
                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">About Me</label>
                                 <textarea 
                                    value={tFormData.about}
                                    onChange={(e) => setTFormData({...tFormData, about: e.target.value})}
                                    className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary h-24 focus:ring-1 focus:ring-primary/20 transition" placeholder="Tell students about your teaching method..." 
                                 />
                             </div>
                         </div>
                    </div>
                </div>
             ) : (
                // --- STUDENT FORM ---
                <div className="space-y-6 animate-slideUp">
                     {/* SECTION A */}
                     <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                         <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex items-center gap-2">
                             <User size={16} className="text-primary"/>
                             <h4 className="text-sm font-bold text-gray-700">Student Information</h4>
                         </div>
                         <div className="p-4 space-y-4">
                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">Student Name</label>
                                 <input 
                                    value={sFormData.name}
                                    onChange={(e) => setSFormData({...sFormData, name: e.target.value})}
                                    className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" placeholder="Name" 
                                 />
                             </div>

                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">Gender</label>
                                 <div className="flex gap-3">
                                    {['male', 'female'].map(g => (
                                        <label key={g} className={`flex-1 p-3 border rounded-lg flex items-center justify-center gap-2 cursor-pointer transition ${sFormData.gender === g ? (g === 'male' ? 'bg-emerald-50 border-emerald-500 text-emerald-700' : 'bg-pink-50 border-pink-500 text-pink-700') : 'bg-white border-gray-200 text-gray-500 hover:bg-gray-50'}`}>
                                            <input type="radio" name="s_gender" checked={sFormData.gender === g} onChange={() => setSFormData({...sFormData, gender: g as any})} className="hidden"/> 
                                            {g === 'male' ? <User size={16} /> : <User size={16} />}
                                            <span className="text-sm font-medium capitalize">{g}</span>
                                        </label>
                                    ))}
                                 </div>
                             </div>
                             
                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">Institution Type (For Icon)</label>
                                 <div className="grid grid-cols-3 gap-3">
                                    {[
                                        { id: 'madrasa', icon: Scroll, label: 'Madrasa' },
                                        { id: 'school', icon: Backpack, label: 'School' },
                                        { id: 'university', icon: GraduationCap, label: 'Varsity' }
                                    ].map((type) => (
                                        <div 
                                            key={type.id}
                                            onClick={() => setSFormData({...sFormData, institutionType: type.id as any})}
                                            className={`p-3 border rounded-xl flex flex-col items-center justify-center gap-2 cursor-pointer transition-all ${sFormData.institutionType === type.id ? 'bg-primary text-white border-primary shadow-md transform scale-105' : 'bg-white text-gray-500 border-gray-200 hover:bg-gray-50'}`}
                                        >
                                            <type.icon size={20} />
                                            <span className="text-[10px] font-bold">{type.label}</span>
                                        </div>
                                    ))}
                                 </div>
                             </div>

                             <div className="grid grid-cols-2 gap-3">
                                 <div>
                                     <label className="block text-xs font-bold text-gray-600 mb-2">Class/Level</label>
                                     <select 
                                        value={sFormData.classLevel}
                                        onChange={(e) => setSFormData({...sFormData, classLevel: e.target.value})}
                                        className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary appearance-none"
                                     >
                                        <option value="" disabled>Select</option>
                                        {getClassList(sFormData.institutionType).map(c => <option key={c} value={c}>{c}</option>)}
                                     </select>
                                 </div>
                                 <div>
                                     <label className="block text-xs font-bold text-gray-600 mb-2">Days/Week</label>
                                     <select 
                                        value={sFormData.daysPerWeek}
                                        onChange={(e) => setSFormData({...sFormData, daysPerWeek: e.target.value})}
                                        className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary appearance-none"
                                     >
                                        <option value="" disabled>Select</option>
                                        {DAYS.map(d => <option key={d} value={d}>{d}</option>)}
                                     </select>
                                 </div>
                             </div>
                         </div>
                    </div>

                    {/* SECTION B */}
                    <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                         <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex items-center gap-2">
                             <Search size={16} className="text-primary"/>
                             <h4 className="text-sm font-bold text-gray-700">Requirements</h4>
                         </div>
                         <div className="p-4 space-y-4">
                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">Need Help With (Subject)</label>
                                 <select 
                                    value={sFormData.need}
                                    onChange={(e) => setSFormData({...sFormData, need: e.target.value})}
                                    className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary appearance-none"
                                 >
                                    <option value="" disabled>Select Subject</option>
                                    {getSubjectList(sFormData.institutionType).map(s => <option key={s} value={s}>{s}</option>)}
                                 </select>
                             </div>

                             <div>
                                <label className="block text-xs font-bold text-gray-600 mb-2">Preferred Mode</label>
                                <div className="flex gap-2">
                                    {['offline', 'online'].map((m) => (
                                        <button 
                                            key={m}
                                            onClick={() => setSFormData({...sFormData, teachingModePreference: m as any})}
                                            className={`flex-1 py-2 rounded-lg text-xs font-bold border transition-all ${sFormData.teachingModePreference === m ? 'bg-gray-800 text-white border-gray-800 shadow' : 'bg-white text-gray-500 border-gray-200 hover:bg-gray-50'}`}
                                        >
                                            {m.toUpperCase()}
                                        </button>
                                    ))}
                                </div>
                             </div>

                             <div className="grid grid-cols-2 gap-3">
                                <div>
                                     <label className="block text-xs font-bold text-gray-600 mb-2">Location</label>
                                     <div className="relative">
                                        <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                                        <input 
                                            value={sFormData.location}
                                            onChange={(e) => setSFormData({...sFormData, location: e.target.value})}
                                            className="w-full pl-10 p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" 
                                            placeholder="e.g. Uttara Sector 4" 
                                        />
                                     </div>
                                </div>

                                <div>
                                     <label className="block text-xs font-bold text-gray-600 mb-2">Budget (BDT)</label>
                                     <div className="relative">
                                        <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-xs">৳</span>
                                        <input 
                                            value={sFormData.budget?.replace(' BDT', '')}
                                            onChange={(e) => setSFormData({...sFormData, budget: e.target.value})}
                                            type="number"
                                            className="w-full pl-6 p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" 
                                            placeholder="e.g. 3000" 
                                        />
                                    </div>
                                </div>
                             </div>

                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">Mobile Number</label>
                                 <div className="relative">
                                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                                    <input 
                                        value={sFormData.mobile}
                                        onChange={(e) => setSFormData({...sFormData, mobile: e.target.value})}
                                        className="w-full pl-10 p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary focus:ring-1 focus:ring-primary/20 transition" placeholder="01XXXXXXXXX" 
                                    />
                                 </div>
                             </div>
                             <div>
                                 <label className="block text-xs font-bold text-gray-600 mb-2">Requirement Details</label>
                                 <textarea 
                                    value={sFormData.details}
                                    onChange={(e) => setSFormData({...sFormData, details: e.target.value})}
                                    className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 outline-none focus:border-primary h-20 focus:ring-1 focus:ring-primary/20 transition" placeholder="Specific requirements..." 
                                 />
                             </div>
                         </div>
                    </div>
                </div>
             )}

             <button className="w-full bg-primary text-white py-4 rounded-xl font-bold shadow-lg mt-8 mb-8 active:scale-95 transition" onClick={handleSaveBioData}>
                 Save & Publish Bio-Data
             </button>
        </div>
    );

    // --- Main Render Flow ---

    if (view === 'login' || view === 'signup') {
        return <AuthScreen type={view} onSwitch={setView} onLogin={() => setView('home')} />;
    }

    return (
        <div className="min-h-screen bg-gray-50 font-sans text-gray-800">
            {view !== 'biodata' && view !== 'create-job' && view !== 'job-detail' && view !== 'job-history' && renderHeader()}
            
            <main className="max-w-md mx-auto bg-white min-h-screen relative shadow-2xl">
                {view === 'home' && renderHome()}
                {view === 'tuition' && renderTuition()}
                {view === 'shop' && renderShop(false)}
                {view === 'digital' && renderShop(true)}
                {view === 'microjob' && renderJobs()}
                {view === 'create-job' && renderCreateJob()}
                {view === 'job-detail' && renderJobDetail()}
                {view === 'job-history' && renderJobHistory()}
                {view === 'profile' && renderProfile()}
                {view === 'biodata' && renderBioData()}
            </main>

            {view !== 'biodata' && view !== 'create-job' && view !== 'job-detail' && view !== 'job-history' && renderBottomNav()}

            {/* Profile Detail Modal Overlay */}
            {selectedProfile && (
                <ProfileDetail 
                    data={selectedProfile.data} 
                    type={selectedProfile.type} 
                    onBack={closeProfile} 
                />
            )}
        </div>
    );
}