import React from 'react';
import { Teacher, Student } from '../types';
import { ArrowLeft, Phone, MessageCircle, MapPin, GraduationCap, Clock, Award, BookOpen, School, User, Baby, Globe, BriefcaseBusiness, Wifi, Backpack, Scroll, CheckCircle } from 'lucide-react';

interface ProfileDetailProps {
    data: Teacher | Student;
    type: 'teacher' | 'student';
    onBack: () => void;
}

const ProfileDetail: React.FC<ProfileDetailProps> = ({ data, type, onBack }) => {
    // Determine if it's a teacher or student for specific fields
    const isTeacher = type === 'teacher';
    const teacherData = isTeacher ? (data as Teacher) : null;
    const studentData = !isTeacher ? (data as Student) : null;

    const handleWhatsApp = () => {
        // WhatsApp Logic: Try to open wa.me
        const number = data.mobile.replace(/\D/g, ''); // strip non-digits
        const formattedNumber = number.startsWith('88') ? number : `88${number}`;
        window.open(`https://wa.me/${formattedNumber}`, '_blank');
    };

    const handleCall = () => {
        window.open(`tel:${data.mobile}`, '_self');
    };

    // Replicating the SmartAvatar logic for the profile detail header
    const getAvatarConfig = () => {
        if (data.gender === 'female') {
            return {
                bg: 'bg-pink-100',
                text: 'text-pink-600',
                icon: <User size={48} />,
                gradient: 'from-pink-500 to-rose-500'
            };
        }
        
        const instType = isTeacher ? teacherData?.institutionType : studentData?.institutionType;
        
        if (instType === 'madrasa') {
            return {
                bg: 'bg-emerald-100',
                text: 'text-emerald-700',
                icon: <User size={48} />, 
                badge: <Scroll size={20} className="absolute -bottom-2 -right-2 bg-white p-1 rounded-full shadow" />,
                gradient: 'from-emerald-600 to-teal-700'
            };
        } else if (instType === 'school') {
            return {
                bg: 'bg-blue-100',
                text: 'text-blue-700',
                icon: <BriefcaseBusiness size={48} />,
                badge: <Backpack size={20} className="absolute -bottom-2 -right-2 bg-white p-1 rounded-full shadow" />,
                gradient: 'from-blue-600 to-indigo-700'
            };
        } else {
             return {
                bg: 'bg-purple-100',
                text: 'text-purple-700',
                icon: <GraduationCap size={48} />,
                badge: <Globe size={20} className="absolute -bottom-2 -right-2 bg-white p-1 rounded-full shadow" />,
                gradient: 'from-purple-600 to-violet-700'
            };
        }
    };

    const config = getAvatarConfig();

    return (
        <div className="fixed inset-0 bg-white z-[200] overflow-y-auto animate-slideUp">
            {/* Header Image / Pattern */}
            <div className={`h-48 bg-gradient-to-br ${config.gradient} relative`}>
                <button 
                    onClick={onBack}
                    className="absolute top-4 left-4 bg-white/20 backdrop-blur-md p-2 rounded-full text-white hover:bg-white/30 transition"
                >
                    <ArrowLeft size={24} />
                </button>
                <div className="absolute -bottom-12 left-1/2 transform -translate-x-1/2">
                    <div className={`w-32 h-32 rounded-full border-4 border-white ${config.bg} ${config.text} flex items-center justify-center shadow-lg relative`}>
                        {config.icon}
                        {/* @ts-ignore - simplified for clarity */}
                        {config.badge}
                    </div>
                </div>
            </div>

            <div className="pt-16 px-6 pb-24 text-center">
                <div className="flex items-center justify-center gap-2 mb-1">
                    <h2 className="text-2xl font-bold text-gray-800">{data.name}</h2>
                    {isTeacher && teacherData?.isVerified && (
                        <div className="bg-blue-500 rounded-full p-0.5 shadow-sm" title="Verified Teacher">
                            <CheckCircle size={14} className="text-white fill-transparent" strokeWidth={3} />
                        </div>
                    )}
                </div>
                
                <div className="flex items-center justify-center gap-2 mb-4">
                     <span className={`text-sm font-bold px-3 py-1 rounded-full bg-gray-100 text-gray-600`}>
                        {isTeacher ? teacherData?.institutionType.toUpperCase() : studentData?.institutionType?.toUpperCase() || 'STUDENT'}
                     </span>
                     {isTeacher && (
                         <span className="text-sm font-bold px-3 py-1 rounded-full bg-emerald-50 text-primary flex items-center gap-1">
                             {teacherData?.teachingMode === 'online' ? <Wifi size={12}/> : <MapPin size={12}/>} 
                             {teacherData?.teachingMode.toUpperCase()}
                         </span>
                     )}
                </div>

                <div className="flex justify-center gap-4 mb-8">
                    <button 
                        onClick={handleWhatsApp}
                        className={`flex-1 ${data.gender === 'female' ? 'bg-pink-600 shadow-pink-600/20' : 'bg-emerald-600 shadow-emerald-600/20'} text-white py-3 px-6 rounded-xl shadow-lg flex items-center justify-center gap-2 font-semibold active:scale-95 transition`}
                    >
                        <MessageCircle size={20} />
                        WhatsApp
                    </button>
                    <button 
                        onClick={handleCall}
                        className="flex-1 bg-gray-100 text-gray-800 py-3 px-6 rounded-xl border border-gray-200 flex items-center justify-center gap-2 font-semibold active:scale-95 transition hover:bg-gray-200"
                    >
                        <Phone size={20} />
                        Call
                    </button>
                </div>

                {/* Details Section */}
                <div className="text-left space-y-4">
                    <h3 className="font-bold text-lg border-b pb-2 mb-4">Detailed Profile</h3>

                    <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex items-start gap-3">
                        <MapPin className="text-gray-400 mt-1" size={20} />
                        <div>
                            <p className="text-xs text-gray-500 uppercase">Present Location</p>
                            <p className="font-medium text-gray-800">{data.location}</p>
                        </div>
                    </div>
                    
                    {isTeacher && teacherData?.targetArea && (
                        <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex items-start gap-3">
                            <Globe className="text-gray-400 mt-1" size={20} />
                            <div>
                                <p className="text-xs text-gray-500 uppercase">Teaching Areas (Coverage)</p>
                                <p className="font-medium text-gray-800">{teacherData.targetArea}</p>
                            </div>
                        </div>
                    )}

                    <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex items-start gap-3">
                        <Award className="text-gray-400 mt-1" size={20} />
                        <div>
                            <p className="text-xs text-gray-500 uppercase">{isTeacher ? "Tuition Fee" : "Budget"}</p>
                            <p className="font-bold text-primary">{isTeacher ? teacherData?.fee : studentData?.budget}</p>
                        </div>
                    </div>

                    {isTeacher && (
                        <>
                            <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex items-start gap-3">
                                <GraduationCap className="text-gray-400 mt-1" size={20} />
                                <div>
                                    <p className="text-xs text-gray-500 uppercase">Qualification</p>
                                    <p className="font-medium text-gray-800">{teacherData?.education}</p>
                                </div>
                            </div>
                            <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex items-start gap-3">
                                <Clock className="text-gray-400 mt-1" size={20} />
                                <div>
                                    <p className="text-xs text-gray-500 uppercase">Teaching Experience</p>
                                    <p className="font-medium text-gray-800">{teacherData?.experience}</p>
                                </div>
                            </div>
                            <div className="mt-6">
                                <p className="text-xs text-gray-500 uppercase mb-2">About The Teacher</p>
                                <p className="text-gray-700 leading-relaxed text-sm bg-white p-4 rounded-xl border shadow-sm whitespace-pre-line">
                                    {teacherData?.about}
                                </p>
                            </div>
                        </>
                    )}

                    {!isTeacher && (
                        <>
                            <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex items-start gap-3">
                                 <Clock className="text-gray-400 mt-1" size={20} />
                                 <div>
                                     <p className="text-xs text-gray-500 uppercase">Class Level</p>
                                     <p className="font-medium text-gray-800">{studentData?.classLevel}</p>
                                 </div>
                            </div>
                             <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex items-start gap-3">
                                 <School className="text-gray-400 mt-1" size={20} />
                                 <div>
                                     <p className="text-xs text-gray-500 uppercase">Schedule</p>
                                     <p className="font-medium text-gray-800">{studentData?.daysPerWeek} ({studentData?.teachingModePreference})</p>
                                 </div>
                            </div>
                            {studentData?.details && (
                                <div className="mt-6">
                                    <p className="text-xs text-gray-500 uppercase mb-2">Requirement Details</p>
                                    <p className="text-gray-700 leading-relaxed text-sm bg-white p-4 rounded-xl border shadow-sm">
                                        {studentData.details}
                                    </p>
                                </div>
                            )}
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ProfileDetail;